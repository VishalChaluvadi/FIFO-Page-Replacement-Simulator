# FIFO PAGE REPLACEMENT SIMULATOR USING C

## 1. Project Details

Project Name: FIFO Page Replacement Simulator  
Student Name: Vishal Chaluvadi  
Roll Number: SE25UCSE113  
University: Mahindra University, Hyderabad  
Branch: CSE  
Section: CSE-2  
Subject: Operating Systems  
Programming Language: C  

## 2. Project Description

The FIFO (First In, First Out) Page Replacement Simulator is a C-based application that demonstrates how an operating system manages memory frames using the FIFO page replacement algorithm.

When a page is requested, the program checks whether it is already present in memory.

- If the page is present, it is counted as a Page Hit.
- If the page is absent, it is counted as a Page Fault.
- If all memory frames are occupied, the oldest loaded page is replaced.

## 3. Concepts Implemented

1. Memory Management
2. Virtual Memory
3. Paging
4. Pages and Frames
5. Page Replacement
6. FIFO Page Replacement Algorithm
7. Page Faults
8. Page Hits
9. Page Fault Ratio
10. Memory Frame Allocation and Tracking

## 4. Features

- Interactive menu-driven interface.
- Normal execution mode.
- Step-by-step execution mode.
- FIFO page replacement simulation.
- Page hit and page fault calculation.
- Memory frame allocation and tracking.
- Hit ratio and page fault ratio calculation.
- Memory utilization calculation.
- Input validation.
- Project information display.

## 5. Software Requirements

- Operating System: Windows
- Programming Language: C
- IDE: Dev-C++
- Compiler: GCC (MinGW)

## 6. How to Compile and Run

1. Open Dev-C++.
2. Open the FIFO_Page_Replacement.c source file.
3. Compile the program.
4. Run the executable.
5. Select an option from the main menu.
6. Enter the number of memory frames.
7. Enter the number of page references.
8. Enter the page reference string.
9. Select Normal Mode or Step-by-Step Mode.
10. View the simulation and final results.

## 7. Sample Input

Number of Frames: 3

Number of Page References: 7

Page Reference String:
1 2 3 1 2 4 1

## 8. Sample Results

Total Page References: 7  
Total Page Hits: 2  
Total Page Faults: 5  

Hit Ratio: 28.57%  
Page Fault Ratio: 71.43%

## 9. Project Files

01_Source_Code - Contains the C source code.

02_Project_Report - Contains the project documentation.

03_Test_Cases - Contains the test cases and expected results.

04_Execution_Screenshots - Contains screenshots of program execution.

05_README - Contains project information and execution instructions.

06_AI_Declaration - Contains the AI usage declaration.

## 10. Conclusion

This project demonstrates the working of the FIFO page replacement algorithm and explains important Operating Systems concepts related to memory management, paging, page faults and page hits.

It provides a practical understanding of how memory frames are allocated and how pages are replaced when memory becomes full.