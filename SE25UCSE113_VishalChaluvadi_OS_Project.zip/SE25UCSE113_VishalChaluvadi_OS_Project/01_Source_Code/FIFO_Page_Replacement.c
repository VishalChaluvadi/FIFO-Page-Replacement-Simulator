
#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <errno.h>
#include <ctype.h>

void displayMenu();
void projectInfo();
void simulateFIFO();
void displayMemory(int memory[], int frames);
int getInput(char message[], int min, int max);

int main()
{
    int choice;

    do
    {
        displayMenu();

        choice = getInput("\nEnter your choice: ", 1, 3);

        switch(choice)
        {
            case 1:
                simulateFIFO();
                break;

            case 2:
                projectInfo();
                break;

            case 3:
                printf("\nThank you for using FIFO Simulator!\n");
                printf("Exiting program...\n");
                break;
        }

    } while(choice != 3);

    return 0;
}

int getInput(char message[], int min, int max)
{
    char input[100];
    char *end;
    long value;

    while(1)
    {
        printf("%s", message);

        if(fgets(input, sizeof(input), stdin) == NULL)
        {
            printf("\nInput error!\n");
            exit(1);
        }

        errno = 0;
        value = strtol(input, &end, 10);

        while(isspace((unsigned char)*end))
        {
            end++;
        }

        if(end == input || *end != '\0' || errno == ERANGE)
        {
            printf("Invalid input! Enter a valid number.\n");
            continue;
        }

        if(value < min || value > max)
        {
            printf("Value must be between %d and %d.\n", min, max);
            continue;
        }

        return (int)value;
    }
}

void displayMenu()
{
    printf("\n");
    printf("================================================\n");
    printf("          FIFO PAGE REPLACEMENT SIMULATOR\n");
    printf("================================================\n");

    printf("\n1. Start Simulation");
    printf("\n2. View Project Information");
    printf("\n3. Exit");

    printf("\n================================================\n");
}

void projectInfo()
{
    printf("\n================================================\n");
    printf("               PROJECT INFORMATION\n");
    printf("================================================\n");

    printf("\nProject Name:");
    printf("\nFIFO Page Replacement Simulator");

    printf("\n\nProgramming Language: C");
    printf("\nSubject: Operating Systems");

    printf("\n\nCONCEPTS IMPLEMENTED:");

    printf("\n1. Memory Management");
    printf("\n2. Virtual Memory");
    printf("\n3. Paging");
    printf("\n4. Pages and Frames");
    printf("\n5. Page Replacement");
    printf("\n6. FIFO Page Replacement Algorithm");
    printf("\n7. Page Faults");
    printf("\n8. Page Hits");
    printf("\n9. Page Fault Ratio");
    printf("\n10. Memory Frame Allocation and Tracking");

    printf("\n\nADDITIONAL FEATURES:");

    printf("\n1. Input Validation");
    printf("\n2. Normal Execution Mode");
    printf("\n3. Step-by-Step Execution");
    printf("\n4. Memory Utilization");
    printf("\n5. Hit Ratio Calculation");

    printf("\n================================================\n");
}

void displayMemory(int memory[], int frames)
{
    int i;

    for(i = 0; i < frames; i++)
    {
        if(memory[i] == -1)
        {
            printf("[ EMPTY ] ");
        }
        else
        {
            printf("[ %d ] ", memory[i]);
        }
    }

    printf("\n");
}

void simulateFIFO()
{
    int frames, n;
    int pages[100], memory[100];

    int i, j;
    int pointer = 0;

    int found;
    int pageHits = 0;
    int pageFaults = 0;

    int occupied = 0;
    int replacedPage;

    int mode;

    float hitRatio;
    float faultRatio;
    float memoryUtilization;
    float averageUtilization = 0;

    printf("\n================================================\n");
    printf("               MEMORY MANAGEMENT\n");
    printf("================================================\n");

    frames = getInput("\nEnter number of memory frames: ", 1, 100 );

    n = getInput("Enter number of page references: ", 1, 100);

    printf("\nEnter the page reference string:\n");

    for(i = 0; i < n; i++)
    {
        char message[50];

        printf(message, "Page %d: ", i + 1);

        pages[i] = getInput(message, 0, INT_MAX);
    }


    printf("\n================================================\n");
    printf("               EXECUTION MODE\n");
    printf("================================================\n");

    printf("\n1. Normal Mode");
    printf("\n2. Step-by-Step Mode");

    mode = getInput("\nEnter execution mode: ", 1, 2);

    for(i = 0; i < frames; i++)
    {
        memory[i] = -1;
    }

    printf("\n================================================\n");
    printf("              FIFO SIMULATION\n");
    printf("================================================\n");

    if(mode == 1)
    {
        printf("\nPage\t");

        for(i = 0; i < frames; i++)
        {
            printf("F%d\t", i + 1);
        }

        printf("Status\tOccupied\n");

        printf("------------------------------------------------\n");
    }

    for(i = 0; i < n; i++)
    {
        found = 0;

        if(mode == 2)
        {
            printf("\n\n================================================\n");
            printf("                    STEP %d\n", i + 1);
            printf("================================================\n");

            printf("\nRequested Page: %d\n", pages[i]);

            printf("\nMemory Before:\n");

            displayMemory(memory, frames);
        }

        for(j = 0; j < frames; j++)
        {
            if(memory[j] == pages[i])
            {
                found = 1;
                break;
            }
        }

        if(found == 1)
        {
            pageHits++;

            if(mode == 2)
            {
                printf("\nPAGE HIT!\n");

                printf("Requested page %d is already in memory.\n",
                       pages[i]);
            }
        }

        else
        {
            replacedPage = memory[pointer];

            if(mode == 2)
            {
                printf("\nPAGE FAULT!\n");

                if(replacedPage == -1)
                {
                    printf("Allocating an empty frame: %d\n",
                           pointer + 1);
                }
                else
                {
                    printf("Replacing Page %d with Page %d\n",
                           replacedPage, pages[i]);
                }
            }

            memory[pointer] = pages[i];

            pointer = (pointer + 1) % frames;

            pageFaults++;
        }

        occupied = 0;
        
        for(j = 0; j < frames; j++)
        {
            if(memory[j] != -1)
            {
                occupied++;
            }
        }


        memoryUtilization =
            ((float)occupied / frames) * 100;

        averageUtilization += memoryUtilization;

        if(mode == 2)
        {
            printf("\nMemory After:\n");

            displayMemory(memory, frames);

            printf("\nAllocated Frames: %d", occupied);

            printf("\nEmpty Frames: %d", frames - occupied);

            printf("\nMemory Utilization: %.2f%%",
                   memoryUtilization);

            printf("\nNext FIFO Frame: %d", pointer + 1);

            printf("\n\nPress ENTER to continue...");

            getchar();
        }

        else
        {
            printf("%d\t", pages[i]);

            for(j = 0; j < frames; j++)
            {
                if(memory[j] == -1)
                {
                    printf("-\t");
                }
                else
                {
                    printf("%d\t", memory[j]);
                }
            }

            if(found == 1)
            {
                printf("HIT\t");
            }
            else
            {
                printf("FAULT\t");
            }

            printf("%d/%d\n", occupied, frames);
        }
    }



    hitRatio = ((float)pageHits / n) * 100;

    faultRatio = ((float)pageFaults / n) * 100;

    memoryUtilization =
        ((float)occupied / frames) * 100;

    averageUtilization = averageUtilization / n;


    printf("\n\n================================================\n");
    printf("                 FINAL RESULTS\n");
    printf("================================================\n");

    printf("\nTotal Page References : %d", n);

    printf("\nTotal Memory Frames  : %d", frames);

    printf("\nAllocated Frames     : %d", occupied);

    printf("\nEmpty Frames         : %d", frames - occupied);

    printf("\n\nTotal Page Hits      : %d", pageHits);

    printf("\nTotal Page Faults    : %d", pageFaults);

    printf("\n\nHit Ratio            : %.2f%%", hitRatio);

    printf("\nPage Fault Ratio     : %.2f%%", faultRatio);

    printf("\n\nFinal Memory Usage   : %.2f%%", memoryUtilization);

    printf("\nAverage Memory Usage : %.2f%%", averageUtilization);

    printf("\n\n================================================\n");
}
